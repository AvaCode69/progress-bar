export const bars = [
  { key: "checkbox-1", id: "progress-1", color: "#4cac54" },
  { key: "checkbox-2", id: "progress-2", color: "#ff5757" },
  { key: "checkbox-3", id: "progress-3", color: "#2194f0" },
  { key: "checkbox-4", id: "progress-4", color: "#e9e952" },
];
