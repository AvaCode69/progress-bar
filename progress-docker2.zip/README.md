# Progress Bar

The Progress Bar is a **Responsive** web application designed to manage and visualize progress tracking for various tasks. It provides users with a user-friendly interface to increment, decrement, and reset progress bars efficiently. The application includes an auto-increment feature that allows progress to be updated automatically, along with a stop button to pause the auto-increment functionality when needed.

## Key Features

- Dynamic Progress Tracking: Users can track the progress of different tasks using visual progress bars.
- Increment and Decrement Controls: Buttons to increase or decrease the progress value by a specified amount.
- Checkbox Selection: Users can select specific progress bars to manipulate based on their current needs.
- Automatic Progress Updates: The application allows users to set an auto-increment feature to update progress automatically, with a **stop button** to pause the auto incrementing process.
- Local Storage Integration: Progress data is saved locally, ensuring that users’ progress is retained even after refreshing the page.

## Live Demo

https://progress-bar-ass.netlify.app

## Install the application

```sh
npm install
```

### Running tests

```sh
npm test
```

### Type-Check, Compile and Minify for Production

```sh
npm  build
```

### Folder structure

**assets/css** : Contains CSS files, including style.css .
**components**: Contains component definitions that manage specific functionalities of the application, such as ProgressBar.js and ProgressControl.js .
**composable/Utils**: The definitions of the reusable components in the project.
**data**: Contains sample data used for demonstration purposes, such as bars.js .
**index.html**: The main HTML file for the application.
**main.js**: The entry point of the application that initializes the app and renders components.

### Framework and Libraries

    - JavaScript
    - HTML
    - CSS
    - Jest: For testing purposes.

- ### Coding Conventions :
  - **Comments**: Inline comments and documentation are used to explain complex logic and important sections of code.
